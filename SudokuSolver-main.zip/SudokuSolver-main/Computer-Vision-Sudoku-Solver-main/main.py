from src.gui import main
from src.get_data import get_data

if __name__ == "__main__":
    main()
    # get_data(1000)